
# Início Rápido (1 clique)

## Windows (recomendado)
- Dê **dois cliques** em `START_IntelliDash_Windows.bat`
- O app abre no navegador automaticamente.

## macOS
- Dê **dois cliques** em `START_IntelliDash_macOS.command`
- Se o macOS pedir permissão, clique em *Abrir* (ou use botão direito > Abrir).

## Linux
- Execute `./start_intellidash_linux.sh`

> Os scripts criam um ambiente `.venv` local e instalam as dependências automaticamente.
